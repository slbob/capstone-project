## Packages
recharts | Visualization for walking stats (bar/line charts)
framer-motion | Smooth page transitions and layout animations
date-fns | Date formatting and manipulation for activity logs
clsx | Utility for conditional classes (standard in shadcn)
tailwind-merge | Utility for merging tailwind classes (standard in shadcn)

## Notes
Replit Auth is already integrated.
Using Lucide React for icons.
Theme: Fresh, energetic Green/Teal palette.
Font: Outfit (Headlines) + Inter (Body).
